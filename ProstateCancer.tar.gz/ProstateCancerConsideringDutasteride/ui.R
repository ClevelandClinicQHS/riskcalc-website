
require(shinythemes)
fluidPage(theme = shinytheme("flatly"),
          tags$head(tags$style(
              HTML('
                 #sidebar {
                    overflow-y:scroll; height: 90vh; position:relative;
                 }')
          )),
          titlePanel('Patients at high risk for prostate cancer - with a prior negative 6 to 12 core biopsy in the past 6 months - considering dutasteride'),
          sidebarLayout(
              sidebarPanel(id = "sidebar"
                           ,
                           textInput('B_OPFPS', '[optional] % free PSA', placeholder = '0 - 100'),
                           textInput('AGE', 'Age (years)', placeholder = '50 - 75'),
                           selectInput('SBSRL', 'Are you sexually active?', choices = c('No', 'Yes', 'Unknown')),
                           textInput('B_BMI', '[optional] BMI (kg/m2)', placeholder = '15 - 50'),
                           selectInput('IMP', 'Do you have a history of impotence?', choices = c('No', 'Yes', 'Unknown')),
                           selectInput('LIB', 'Do you have a history of libido problems?', choices = c('No', 'Yes', 'Unknown')),
                           selectInput('HIS_PCA', 'Do you have family history of prostate cancer', choices = c('No', 'Yes', 'Unknown')),
                           textInput('B_IPSS', '[optional] IPSS score', placeholder = '0 - 25'),
                           textInput('B_QM', '[optional] Maximum urinary flow rate (Qmax, ml/s)', placeholder = '0 - 100'),
                           textInput('B_NOCOR', '[optional] Number of biopsy cores', placeholder = '6 - 12'),
                           textInput('B_OPSA', 'Prostate Specific Antigen (PSA)', placeholder = '2 - 10'),
                           textInput('B_OPSA', 'Prostate Specific Antigen (PSA)', placeholder = '2 - 10'),
                           textInput('B_PV', '[optional] Prostate volume (cm3)', placeholder = '0 - 80'),
                           textInput('B_RSD', '[optional] Residual urine volume (cm3)', placeholder = '>=0'),
                           selectInput('B_DRE', 'What is the DRE result?', choices = c('Normal', 'Abnormal', 'Unknown'))),
              mainPanel(
                  actionButton("goButton", "Run Calculator"),
                  br(),
                  hr(),
                  tags$head(
                      tags$style(type="text/css", "tfoot {display:none;}")
                  ),
                  dataTableOutput('result'),
                  br(),
                  wellPanel(h3('Reference'),
                            p("[1] Andriole GL, Bostwick DG, Brawley OW, Gomella LG, Marberger M, Montorsi F, Pettaway CA, Tammela TL, Teloken C, Tindall DJ, Somerville MC, Wilson TH, Fowler IL, Rittmaster RS; REDUCE Study Group.. ",a('Effect of dutasteride on the risk of prostate cancer.', href='http://www.nejm.org/doi/pdf/10.1056/NEJMoa0908127'),". N Engl J Med. 2010 Apr 1;362(13):1192-202. doi: 10.1056/NEJMoa0908127."),
                            p("[2] Carvell T. Nguyen, Brandon Isariyawongse, Changhong Yu and Michael W. Kattan. ",a('The REDUCE metagram: a comprehensive prediction tool for determining the utility of dutasteride chemoprevention in men at risk for prostate cancer', href='http://journal.frontiersin.org/article/10.3389/fonc.2012.00138/abstract'),". Front. Oncol., 11 October 2012 | http://dx.doi.org/10.3389/fonc.2012.00138")),
                  p(a("Homepage",
                      href = "../index", style = "font-family: 'Lato','Helvetica Neue',Helvetica,Arial,sans-serif;
                      font-size: 15px;color: #2c3e50;font-weight: bold;text-align: center;text-decoration: underline;"), 
                    " | ",
                    a("Contact Us",
                      href = "mailto:ralcsupport@ccf.org", style = "font-family: 'Lato','Helvetica Neue',Helvetica,Arial,sans-serif;
                      font-size: 15px;color: #2c3e50;font-weight: bold;text-align: center;text-decoration: underline;"), 
                    style = "text-align: center;"),
                  img(src='../CC_c.jpg', style = "max-width:30%; max-height:100%;"))))