library(shiny)
library(shinyjs)
library(yonder)
library(kableExtra)

shiny::addResourcePath("shinyjs", system.file("srcjs", package = "shinyjs"))

source("samplesize.R", local = T)
