function(input, output, session) {
    useShinyjs(html = TRUE)
    
    design <- reactiveVal("Introduction")
    
    observeEvent(input$design,{
        if (input$design=="Introduction") {
            shinyjs::show(id="introduction")
            shinyjs::hide(id="outcome_rct")
            shinyjs::hide(id="outcome_cc")
            shinyjs::hide(id="outcome_cohort")
            shinyjs::hide(id="outcome_cross")
            shinyjs::hide(id="outcome_survey")
        }
        if (input$design %in% c("NonInferiority", "Superiority", "Equivalence")) {
            shinyjs::hide(id="introduction")
            shinyjs::show(id="outcome_rct")
            shinyjs::hide(id="outcome_cc")
            shinyjs::hide(id="outcome_cohort")
            shinyjs::hide(id="outcome_cross")
            shinyjs::hide(id="outcome_survey")
        }
        if (input$design == "CaseControl") {
            shinyjs::hide(id="introduction")
            shinyjs::hide(id="outcome_rct")
            shinyjs::show(id="outcome_cc")
            shinyjs::hide(id="outcome_cohort")
            shinyjs::hide(id="outcome_cross")
            shinyjs::hide(id="outcome_survey")
        }
        if (input$design == "Cohort") {
            shinyjs::hide(id="introduction")
            shinyjs::hide(id="outcome_rct")
            shinyjs::hide(id="outcome_cc")
            shinyjs::show(id="outcome_cohort")
            shinyjs::hide(id="outcome_cross")
            shinyjs::hide(id="outcome_survey")
        }
        if (input$design == "CrossSectional") {
            shinyjs::hide(id="introduction")
            shinyjs::hide(id="outcome_rct")
            shinyjs::hide(id="outcome_cc")
            shinyjs::hide(id="outcome_cohort")
            shinyjs::show(id="outcome_cross")
            shinyjs::hide(id="outcome_survey")
        }
        if (input$design == "Survey") {
            shinyjs::hide(id="introduction")
            
            shinyjs::hide(id="outcome_rct")
            shinyjs::hide(id="outcome_cc")
            shinyjs::hide(id="outcome_cohort")
            shinyjs::hide(id="outcome_cross")
            shinyjs::show(id="outcome_survey")
        }
        if(input$design=="Introduction") {
            shinyjs::hide(id="run-tab")
            shinyjs::hide(id="DesignTitle")
        } else {
            shinyjs::show(id="run-tab")
            shinyjs::show(id="DesignTitle")
        }
        if(!is.null(input$design)) {
            design(input$design)
        }
    })
    
    output$summary <- renderUI({
        d = design()
        if (d == "NonInferiority") {
            h1("Non-inferiority Trial")
        } else if (d == "Superiority") {
            h1("Superiority Trial")
        } else if (d == "Equivalence") {
            h1("Equivalence Trial")
        } else if (d=="CaseControl") {
            h1("Case-control Study")
        } else if (d=="Cohort") {
            h1("Cohort Study")
        } else if (d=="CrossSectional") {
            h1("Cross-sectional Study")
        } else if (d=="Survey") {
            h1("Survey (Cross-sectional)")
        }
    })
    
    observeEvent(input$rctDesign,
                 {
                     showNavPane(input$rctDesign)
                 })
    observeEvent(input$ccDesign,
                 {
                     showNavPane(input$ccDesign)
                 })
    observeEvent(input$cohortDesign,
                 {
                     showNavPane(input$cohortDesign)
                 })
    observeEvent(input$independentDesign,
                 {
                     showNavPane(input$independentDesign)
                 })
    observeEvent(input$crossDesign,
                 {
                     showNavPane(input$crossDesign)
                 })
    observeEvent(input$surveyDesign,
                 {
                     showNavPane(input$surveyDesign)
                 })

    rct_mean_values <- reactiveValues(
        lastUpdated = NULL
    )
    observe({
        lapply(c("rct_mean_treat", "rct_mean_control"), function(x) {
            observe({
                input[[x]]
                rct_mean_values$lastUpdated <- x
            })
        })
    })
    
    observeEvent(input$radiobar1, {
        if (input$radiobar1 == "proportion") {
            shinyjs::show("rctProportion")
            shinyjs::hide("rctOR")
        } else {
            shinyjs::hide("rctProportion")
            shinyjs::show("rctOR")
        }
    })
    
    observeEvent(input$radiobar2, {
        if (input$radiobar2 == "known") {
            shinyjs::show("known")
            shinyjs::hide("unknown")
        } else {
            shinyjs::hide("known")
            shinyjs::show("unknown")
        }
    })
    
    observeEvent(input$radiobar3, {
        if (input$radiobar3 == "ccproportion") {
            shinyjs::show("ccproportion")
            shinyjs::hide("ccor")
        } else {
            shinyjs::hide("ccproportion")
            shinyjs::show("ccor")
        }
    })
    
    observeEvent(input$radiobar4, {
        if (input$radiobar4 == "cohortproportion") {
            shinyjs::show("cohortproportion")
            shinyjs::hide("cohortrr")
        } else {
            shinyjs::hide("cohortproportion")
            shinyjs::show("cohortrr")
        }
    })
    
    observeEvent(input$radiobar5, {
        if (input$radiobar5 == "known") {
            shinyjs::show("cohortknown")
            shinyjs::hide("cohortunknown")
        } else {
            shinyjs::hide("cohortknown")
            shinyjs::show("cohortunknown")
        }
    })
    
    observeEvent(input$radiobar6, {
        if (input$radiobar6 == "crossproportion") {
            shinyjs::show("crossproportion-p")
            shinyjs::hide("crossrr-p")
        } else {
            shinyjs::hide("crossproportion-p")
            shinyjs::show("crossrr-p")
        }
    })
    
    v = reactiveValues(res = NULL)
    
    observeEvent(input$run,{
        if (input$design %in% c("NonInferiority", "Superiority", "Equivalence") & input$rctDesign=="continuous"){
            res = rct_continuous(diff=input$rct_mean_diff, delta=input$rct_delta_c, sd=input$rct_sd, 
                                 r=input$r_rct_c, power=input$beta_rct_c, alpha=input$alpha_rct_c, drop_rate = input$dr_c/100, design=input$design)
                output_data = data.frame(
                    V1 = c("Significance level", "Power (1-beta)", "Ratio of sample size, treat/control", "Allowable difference", "SD", "Margin", "Drop rate (%)", "Result", "Sample Size - Treat", "Sample Size - Control", "Total sample size"),
                    V2 = c(input$alpha_rct_c, input$beta_rct_c, input$r_rct_c, input$rct_mean_diff, input$rct_sd, input$rct_delta_c, input$dr_c, "", res$n_treat, res$n_control, res$n_total)
                ) %>% 
                    knitr::kable("html", escape = F, align=c("l", "c")) %>% 
                    kable_styling(bootstrap_options = c("striped", "hover"), full_width = F) %>% 
                    row_spec(9, bold = T, background = "#EEF5DB") %>% 
                    add_header_above(c("Sample size"=2), background = "#666666", color = "#ffffff")
                output_data = gsub("</th></tr>.*</thead>","</thead>", output_data)
                v$res = output_data
        }
        if (input$design %in% c("NonInferiority", "Superiority", "Equivalence") & input$rctDesign=="dichotomous"){
            if (input$radiobar1 == "proportion") {
                res = rct_proportion(treat=input$rct_p_treat, control=input$rct_p_control,  
                                 delta=input$rct_delta_p, 
                                 r=input$r_rct_p, power=input$beta_rct_p, alpha=input$alpha_rct_p, drop_rate = input$dr_d/100, design=input$design)
                output_data = data.frame(
                    V1 = c("Significance level", "Power (1-beta)", "Ratio of sample size, treat/control", "Expected proportion in the treatment group", "Expected proportion in the control group","Margin", "Drop rate (%)", "Result", "Sample Size - Treat", "Sample Size - Control", "Total sample size"),
                    V2 = c(input$alpha_rct_p, input$beta_rct_p, input$r_rct_p, input$rct_p_treat, input$rct_p_control, input$rct_delta_p,input$dr_d, "", res$n_treat, res$n_control, res$n_total)
                ) %>% 
                    knitr::kable("html", escape = F, align=c("l", "c")) %>% 
                    kable_styling(bootstrap_options = c("striped", "hover"), full_width = F) %>% 
                    row_spec(8, bold = T, background = "#EEF5DB") %>% 
                    add_header_above(c("Sample size"=2), background = "#666666", color = "#ffffff")
                output_data = gsub("</th></tr>.*</thead>","</thead>", output_data)
                v$res = output_data
            } else {
                res = rct_proportion(OR = input$rct_p_or,  
                                     delta=input$rct_deltaexp_p, 
                                     r=input$r_rct_p, power=input$beta_rct_p, alpha=input$alpha_rct_p, design=input$design)
                output_data = data.frame(
                    V1 = c("Significance level", "Power (1-beta)", "Ratio of sample size, treat/control", "Odds ratio","Margin in log-scale", "Result", "Sample Size - Treat", "Sample Size - Control", "Total sample size"),
                    V2 = c(input$alpha_rct_p, input$beta_rct_p, input$r_rct_p, input$rct_p_or, input$rct_deltaexp_p, "", res$n_treat, res$n_control, res$n_total)
                ) %>% 
                    knitr::kable("html", escape = F, align=c("l", "c")) %>% 
                    kable_styling(bootstrap_options = c("striped", "hover"), full_width = F) %>% 
                    row_spec(6, bold = T, background = "#EEF5DB") %>% 
                    add_header_above(c("Sample size"=2), background = "#666666", color = "#ffffff")
                output_data = gsub("</th></tr>.*</thead>","</thead>", output_data)
                v$res = output_data
            }
        }
        if (input$design %in% c("NonInferiority", "Superiority", "Equivalence") & input$rctDesign=="tte") {
            if (input$radiobar2 == "known") {
                res = rct_survival(HR=input$rct_s_hr, delta=input$rct_delta_s, pi_treat=input$rct_s_treat, pi_control=input$rct_s_control, r=input$r_rct_s, power=input$beta_rct_s, alpha=input$alpha_rct_s)
            } else {
                res = rct_survival(HR=input$rct_s_hr, delta=input$rct_delta_s, ta=input$rct_s_timea, tb=input$rct_s_timeb, r=input$r_rct_s, power=input$beta_rct_s, alpha=input$alpha_rct_s)
            }
            output_data = data.frame(
                V1 = c("Significance level", "Power (1-beta)", "Ratio of sample size, treat/control", "Hazard ratio", "Margin", "Probability of event in the treat group", "Probability of event in the control group", "Result", "Sample Size - Treat", "Sample Size - Control", "Total sample size"),
                V2 = c(input$alpha_rct_s, input$beta_rct_s, input$r_rct_s, input$rct_s_hr, input$rct_delta_s, round(res$pi_treat, 3), round(res$pi_control, 3), "", res$n_treat, res$n_control, res$n_total)
            ) %>% 
                knitr::kable("html", escape = F, align=c("l", "c")) %>% 
                kable_styling(bootstrap_options = c("striped", "hover"), full_width = F) %>% 
                row_spec(8, bold = T, background = "#EEF5DB") %>% 
                add_header_above(c("Sample size"=2), background = "#666666", color = "#ffffff")
            output_data = gsub("</th></tr>.*</thead>","</thead>", output_data)
            v$res = output_data
        }
        if (input$design == "CaseControl" & input$ccDesign=="unmatched") {
            twoside = ifelse(is.null(input$checkbox1), F, T)
            if (input$radiobar3=="ccproportion") {
                res = cc(p0=input$unmatched_p0, p1=input$unmatched_p1, r=input$r_unmatched, alpha=input$alpha_unmatched, power=input$beta_unmatched, two.side=twoside, design = "unmatched")
                output_data = data.frame(
                    V1 = c(ifelse(twoside, "2-side significance level", "1-side significance level"), "significance level (1-alpha)", "Power (1-beta)", "Ratio of sample size, control/case", "Probability of event in the case group", "Probability of event in the control group", "Result", "", "Sample Size - Case", "Sample Size - Control", "Total sample size"),
                    V2 = c(rep("", 6), "Fleiss", res$fless.case, res$fless.control, res$fless.case+ res$fless.control),
                    V3 = c(input$alpha_unmatched, input$beta_unmatched, input$r_unmatched, input$unmatched_p0, input$unmatched_p1, "", "Fleiss with correction for continuity", res$flesscc.case, res$flesscc.control, res$flesscc.case+res$flesscc.control)
                ) %>% 
                    knitr::kable("html", escape = F, align=c("l", "c", "c")) %>% 
                    kable_styling(bootstrap_options = c("striped", "hover"), full_width = F) %>% 
                    row_spec(6, bold = T, background = "#EEF5DB") %>% 
                    row_spec(7, bold = T) %>% 
                    add_header_above(c("Sample size"=3), background = "#666666", color = "#ffffff")
                output_data = gsub("</th></tr>.*</thead>","</thead>", output_data)
                v$res = output_data
            } else {
                res = cc(OR =input$unmatched_or, r=input$r_unmatched, alpha=input$alpha_unmatched, power=input$beta_unmatched, two.side=twoside, design = "unmatched")
                output_data = data.frame(
                    V1 = c(ifelse(twoside, "2-side significance level", "1-side significance level"), "Power (1-beta)", "Ratio of sample size, control/case", "OR", "Result","", "Sample Size - Case", "Sample Size - Control", "Total sample size"),
                    V2 = c(rep("", 5), "Fleiss", res$fless.case, res$fless.control, res$fless.case+ res$fless.control),
                    V3 = c(1-input$alpha_unmatched, input$beta_unmatched, input$r_unmatched, input$unmatched_or, "", "Fleiss with correction for continuity", res$flesscc.case, res$flesscc.control, res$flesscc.case+res$flesscc.control)
                ) %>% 
                    knitr::kable("html", escape = F, align=c("l", "c", "c")) %>% 
                    kable_styling(bootstrap_options = c("striped", "hover"), full_width = F) %>% 
                    row_spec(5, bold = T, background = "#EEF5DB") %>% 
                    row_spec(6, bold = T) %>% 
                    add_header_above(c("Sample size"=3), background = "#666666", color = "#ffffff")
                output_data = gsub("</th></tr>.*</thead>","</thead>", output_data)
                v$res = output_data
            }
        }
        if (input$design == "CaseControl" & input$ccDesign=="matched") {
            twoside = ifelse(is.null(input$checkbox2), F, T)
            res = cc(p0=input$matched_p0, p1=input$matched_p1, r=input$r_matched, alpha=input$alpha_matched, power=input$beta_matched, two.side=twoside, design = "matched") 
            output_data = data.frame(
                V1 = c(ifelse(twoside, "2-side significance level", "1-side significance level"), "Power (1-beta)", "Ratio of sample size, control/case", "Probability of event in the case group", "Probability of event in the control group", "Result", "Sample Size - Case", "Sample Size - Control", "Total sample size"),
                V2 = c(input$alpha_matched, input$beta_matched, input$r_matched, input$matched_p0, input$matched_p1, "", res$n.case, res$n.control, res$n.case+res$n.control)
            ) %>% 
                knitr::kable("html", escape = F, align=c("l", "c", "c")) %>% 
                kable_styling(bootstrap_options = c("striped", "hover"), full_width = F) %>% 
                row_spec(6, bold = T, background = "#EEF5DB") %>% 
                add_header_above(c("Sample size"=2), background = "#666666", color = "#ffffff")
            output_data = gsub("</th></tr>.*</thead>","</thead>", output_data)
            v$res = output_data
        }
        if (input$design == "Cohort" & input$cohortDesign=="independent" & input$independentDesign=="independentProportional") {
            twoside = ifelse(is.null(input$checkbox3), F, T)
            if (input$radiobar4=="cohortproportion") {
                res = cohort(p1=input$ind_p0, p2=input$ind_p1, r=input$r_ind, alpha=input$alpha_ind, power=input$beta_ind, two.side=twoside, drop_rate=input$dr_i/100, design = "independent")
                output_data = data.frame(
                    V1 = c(ifelse(twoside, "2-side significance level", "1-side significance level"), "Power (1-beta)", "Ratio of sample size, unexposed/exposed", "Probability of event in the unexposed group", "Probability of event in the exposed group", "Drop rate (%)", "Result", "", "Sample Size - Exposed", "Sample Size - Unexposed", "Total sample size"),
                    V2 = c(rep("", 7), "Fleiss", res$n_exposed, res$n_unexposed, res$n_exposed+res$n_unexposed),
                    V3 = c(input$alpha_ind, input$beta_ind, input$r_ind, input$ind_p0, input$ind_p1, input$dr_i, "", "Fleiss with correction for continuity", res$n_exposed_cc, res$n_unexposed_cc, res$n_exposed_cc+res$n_unexposed_cc)
                ) %>% 
                    knitr::kable("html", escape = F, align=c("l", "c", "c")) %>% 
                    kable_styling(bootstrap_options = c("striped", "hover"), full_width = F) %>% 
                    row_spec(7, bold = T, background = "#EEF5DB") %>% 
                    row_spec(8, bold = T) %>% 
                    add_header_above(c("Sample size"=3), background = "#666666", color = "#ffffff")
                output_data = gsub("</th></tr>.*</thead>","</thead>", output_data)
                v$res = output_data
            } else {
                res = cohort(RR=input$ind_rr, r=input$r_ind, alpha=input$alpha_ind, power=input$beta_ind, two.side=twoside, drop_rate=input$dr_i/100, design = "independent")
                output_data = data.frame(
                    V1 = c(ifelse(twoside, "2-side significance level", "1-side significance level"), "Power (1-beta)", "Ratio of sample size, unexposed/exposed", "Relatvie Risk (p1/p0)","Drop rate (%)", "Result","", "Sample Size - Exposed", "Sample Size - Unexposed", "Total sample size"),
                    V2 = c(rep("", 6), "Fleiss", res$n_exposed, res$n_unexposed, res$n_exposed+res$n_unexposed),
                    V3 = c(input$alpha_ind, input$beta_ind, input$r_ind, input$ind_rr,input$dr_i, "", "Fleiss with correction for continuity", res$n_exposed_cc, res$n_unexposed_cc, res$n_exposed_cc+res$n_unexposed_cc)
                ) %>% 
                    knitr::kable("html", escape = F, align=c("l", "c", "c")) %>% 
                    kable_styling(bootstrap_options = c("striped", "hover"), full_width = F) %>% 
                    row_spec(6, bold = T, background = "#EEF5DB") %>% 
                    row_spec(7, bold = T) %>% 
                    add_header_above(c("Sample size"=3), background = "#666666", color = "#ffffff")
                output_data = gsub("</th></tr>.*</thead>","</thead>", output_data)
                v$res = output_data
            }
        }
        if (input$design == "Cohort" & input$cohortDesign=="independent" & input$independentDesign=="independentContinuous") {
            twoside = ifelse(is.null(input$checkbox8), F, T)
            res = cross_sectional(p1=input$indc_m1, p2=input$indc_m2, variance=(input$sd_indc)^2, r=input$r_indc, alpha=input$alpha_indc, power=input$beta_indc, two.side=twoside, design = "continuous")
            output_data = data.frame(
                V1 = c(ifelse(twoside, "2-side significance level", "1-side significance level"), "Power (1-beta)", "Ratio of sample size, unexposed/exposed group", "Expected mean in unexposed group", "Expected mean in exposed group", "Population standard deviation", "Result", "Sample Size - unexposed group", "Sample Size - exposed group", "Total sample size"),
                V2 = c(input$alpha_indc, input$beta_indc, input$r_indc, input$indc_m1, input$indc_m2, input$sd_indc, "", res$n1, res$n2, res$n1+res$n2)
            ) %>% 
                knitr::kable("html", escape = F, align=c("l", "c")) %>% 
                kable_styling(bootstrap_options = c("striped", "hover"), full_width = F) %>% 
                row_spec(7, bold = T, background = "#EEF5DB") %>% 
                add_header_above(c("Sample size"=2), background = "#666666", color = "#ffffff")
            output_data = gsub("</th></tr>.*</thead>","</thead>", output_data)
            v$res = output_data
        }
        if (input$design == "Cohort" & input$cohortDesign=="paired") {
            twoside = ifelse(is.null(input$checkbox4), F, T)
            res=cohort(p1=input$cohort_pair_p0, p2=input$cohort_pair_p1, alpha=input$alpha_cohort_pair, power=input$beta_cohort_pair, two.side=twoside, drop_rate=input$dr_pair/100, design = "paired")
            output_data = data.frame(
                V1 = c(ifelse(twoside, "2-side significance level", "1-side significance level"), "Power (1-beta)", "Probability of event in the exposed group", "Probability of event in the unexposed group", "Drop rate (%)", "Result", "Sample Size - Exposed", "Sample Size - Unexposed", "Total sample size"),
                V2 = c(input$alpha_cohort_pair, input$beta_cohort_pair, input$cohort_pair_p0, input$cohort_pair_p1, input$dr_pair, "", res$n_exposed, res$n_unexposed, res$n_exposed+res$n_unexposed)
            ) %>% 
                knitr::kable("html", escape = F, align=c("l", "c", "c")) %>% 
                kable_styling(bootstrap_options = c("striped", "hover"), full_width = F) %>% 
                row_spec(6, bold = T, background = "#EEF5DB") %>% 
                add_header_above(c("Sample size"=2), background = "#666666", color = "#ffffff")
            output_data = gsub("</th></tr>.*</thead>","</thead>", output_data)
            v$res = output_data
        }
        if (input$design == "Cohort" & input$cohortDesign=="cohorttte") {
            twoside = ifelse(is.null(input$checkbox5), F, T)
            if (input$radiobar5 == "known") {
                res = cohort_survival(p1=input$cohort_tte_p1, p2=input$cohort_tte_p2, HR=input$cohort_tte_hr, r=input$r_cohort_tte, alpha=input$alpha_cohort_tte, power=input$beta_cohort_tte, two.side=twoside)
            } else {
                res = cohort_survival(ta=input$cohort_tte_timea, tb=input$cohort_tte_timeb, HR=input$cohort_tte_hr, r=input$r_cohort_tte, alpha=input$alpha_cohort_tte, power=input$beta_cohort_tte, two.side=twoside)
            }
            output_data = data.frame(
                V1 = c(ifelse(twoside, "2-side significance level", "1-side significance level"), "Power (1-beta)", "Ratio of sample size, unexposed/exposed", "Hazard ratio", "Probability of event in the exposed group", "Probability of event in the unexposed group", "Result", "Sample Size - Exposed", "Sample Size - Unexposed", "Total sample size"),
                V2 = c(input$alpha_cohort_tte, input$beta_cohort_tte, input$r_cohort_tte, input$cohort_tte_hr, round(res$p2,3), round(res$p1,3), "", res$n_exposed, res$n_unexposed, res$n_exposed+res$n_unexposed)
            ) %>% 
                knitr::kable("html", escape = F, align=c("l", "c")) %>% 
                kable_styling(bootstrap_options = c("striped", "hover"), full_width = F) %>% 
                row_spec(7, bold = T, background = "#EEF5DB") %>% 
                add_header_above(c("Sample size"=2), background = "#666666", color = "#ffffff")
            output_data = gsub("</th></tr>.*</thead>","</thead>", output_data)
            v$res = output_data
        }
        if (input$design == "CrossSectional" & input$crossDesign=="crosscontinuous") {
            twoside = ifelse(is.null(input$checkbox6), F, T)
            res = cross_sectional(p1=input$cross_m1, p2=input$cross_m2, variance=(input$sd_cross)^2, r=input$r_cross, alpha=input$alpha_cross, power=input$beta_cross, two.side=twoside, design = "continuous")
            output_data = data.frame(
                V1 = c(ifelse(twoside, "2-side significance level", "1-side significance level"), "Power (1-beta)", "Ratio of sample size, first group/second group", "Expected mean in first group", "Expected mean in second group", "Population standard deviation", "Result", "Sample Size - first group", "Sample Size - second group", "Total sample size"),
                V2 = c(input$alpha_cross, input$beta_cross, input$r_cross, input$cross_m1, input$cross_m2, input$sd_cross, "", res$n1, res$n2, res$n1+res$n2)
            ) %>% 
                knitr::kable("html", escape = F, align=c("l", "c")) %>% 
                kable_styling(bootstrap_options = c("striped", "hover"), full_width = F) %>% 
                row_spec(7, bold = T, background = "#EEF5DB") %>% 
                add_header_above(c("Sample size"=2), background = "#666666", color = "#ffffff")
            output_data = gsub("</th></tr>.*</thead>","</thead>", output_data)
            v$res = output_data
        }
        if (input$design == "CrossSectional" & input$crossDesign=="crossproportion") {
            twoside = ifelse(is.null(input$checkbox7), F, T)
            if (input$radiobar6=="crossproportion") {
                res = cross_sectional(p1=input$cross_p1, p2=input$cross_p2, r=input$r_cross_p, alpha=input$alpha_cross_p, power=input$beta_cross_p, two.side=twoside, design = "proportion")
                output_data = data.frame(
                    V1 = c(ifelse(twoside, "2-side significance level", "1-side significance level"), "Power (1-beta)", "Ratio of sample size, first group/second group", "Probability of event in first group", "Probability of event in second group", "Result", "", "Sample Size - first group", "Sample Size - second group", "Total sample size"),
                    V2 = c(rep("", 6), "Fleiss", res$n1, res$n2, res$n1+res$n2),
                    V3 = c(input$alpha_cross_p, input$beta_cross_p, input$r_cross_p, input$cross_p1, input$cross_p2, "", "Fleiss with correction for continuity", res$n1_cc, res$n2_cc, res$n1_cc+res$n2_cc)
                ) %>% 
                    knitr::kable("html", escape = F, align=c("l", "c", "c")) %>% 
                    kable_styling(bootstrap_options = c("striped", "hover"), full_width = F) %>% 
                    row_spec(6, bold = T, background = "#EEF5DB") %>% 
                    row_spec(7, bold = T) %>% 
                    add_header_above(c("Sample size"=3), background = "#666666", color = "#ffffff")
                output_data = gsub("</th></tr>.*</thead>","</thead>", output_data)
                v$res = output_data
            } else {
                res =cross_sectional(RR=input$cross_rr, r=input$r_cross_p, alpha=input$alpha_cross_p, power=input$beta_cross_p, two.side=twoside, design = "proportion")
                output_data = data.frame(
                    V1 = c(ifelse(twoside, "2-side significance level", "1-side significance level"), "Power (1-beta)", "Ratio of sample size, first group/second group", "Relatvie Risk (p2/p1)", "Result","", "Sample Size - first group", "Sample Size - second group", "Total sample size"),
                    V2 = c(rep("", 5), "Fleiss", res$n1, res$n2, res$n1+res$n2),
                    V3 = c(input$alpha_cross_p, input$beta_cross_p, input$r_cross_p, input$cross_rr, "", "Fleiss with correction for continuity", res$n1_cc, res$n2_cc, res$n1_cc+res$n2_cc)
                ) %>% 
                    knitr::kable("html", escape = F, align=c("l", "c", "c")) %>% 
                    kable_styling(bootstrap_options = c("striped", "hover"), full_width = F) %>% 
                    row_spec(5, bold = T, background = "#EEF5DB") %>% 
                    row_spec(6, bold = T) %>% 
                    add_header_above(c("Sample size"=3), background = "#666666", color = "#ffffff")
                output_data = gsub("</th></tr>.*</thead>","</thead>", output_data)
                v$res = output_data
            }
        }
        if (input$design == "Survey" & input$surveyDesign=="surveycontinuous") {
            res = survey(v=input$survey_sd, d=input$survey_sd_d, alpha=input$alpha_survey_c, two.side=T, design="continuous")
            output_data = data.frame(
                V1 = c("2-side significance level", "SD", "d", "Result", "Total sample size"),
                V2 = c(input$alpha_survey_c, input$survey_sd, input$survey_sd_d, "", res$n)
            ) %>% 
                knitr::kable("html", escape = F, align=c("l", "c")) %>% 
                kable_styling(bootstrap_options = c("striped", "hover"), full_width = F) %>% 
                row_spec(4, bold = T, background = "#EEF5DB") %>% 
                add_header_above(c("Sample size"=2), background = "#666666", color = "#ffffff")
            output_data = gsub("</th></tr>.*</thead>","</thead>", output_data)
            v$res = output_data
        }
        if (input$design == "Survey" & input$surveyDesign=="surveyproportion") {
            res = survey(v=input$survey_p, d=input$survey_p_d, alpha=input$alpha_survey_p, two.side=T, design="proportion")
            output_data = data.frame(
                V1 = c("2-side significance level", "p", "d", "Result", "Total sample size"),
                V2 = c(input$alpha_survey_p, input$survey_p, input$survey_p_d, "", res$n)
            ) %>% 
                knitr::kable("html", escape = F, align=c("l", "c")) %>% 
                kable_styling(bootstrap_options = c("striped", "hover"), full_width = F) %>% 
                row_spec(4, bold = T, background = "#EEF5DB") %>% 
                add_header_above(c("Sample size"=2), background = "#666666", color = "#ffffff")
            output_data = gsub("</th></tr>.*</thead>","</thead>", output_data)
            v$res = output_data
        }
        shinyjs::show("tableOutput", anim = T)
        })
    
    output$summary_table <- renderText({
        v$res
    })

    observe({
        lapply(names(input)[names(input)!="run"], function(x) {
            observeEvent(input[[x]], {
                shinyjs::hide("tableOutput", anim = T)
                v$res = NULL
            })
        })
    })
}